import streamlit as st
import cv2
import torch
import numpy as np

from PIL import Image

from model import StrongDINOv2Seg
from utils import *

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
WEIGHTS = r"D:\remoteSensingWebApp\checkpoints\best_model.pth"


@st.cache_resource
def load_model():

    model = StrongDINOv2Seg().to(DEVICE)

    checkpoint = torch.load(
        WEIGHTS,
        map_location=DEVICE
    )

    model.load_state_dict(
        checkpoint["state_dict"],
        strict=False
    )

    model.eval()

    return model


model = load_model()


@torch.no_grad()
def predict(image):

    image_rgb = np.array(image)

    resized = cv2.resize(
        image_rgb,
        (560,560)
    )

    tensor = (
        torch.tensor(
            resized.astype(np.float32)/255.0
        )
        .permute(2,0,1)
        .unsqueeze(0)
        .to(DEVICE)
    )

    logits = model(tensor)

    pred = torch.argmax(
        logits,
        dim=1
    )

    pred = pred.squeeze().cpu().numpy()

    return resized,pred


st.set_page_config(
    page_title="Rural Infrastructure Mapping",
    layout="wide"
)

st.title("🏡 Rural Infrastructure Mapping System")

uploaded_file = st.file_uploader(
    "Upload Satellite Image",
    type=["png","jpg","jpeg"]
)

if uploaded_file:

    image = Image.open(uploaded_file).convert("RGB")

    original,pred = predict(image)

    mask = colorize_mask(pred)

    overlay = cv2.addWeighted(
        original,
        0.6,
        mask,
        0.4,
        0
    )

    col1,col2,col3 = st.columns(3)

    with col1:
        st.image(original,caption="Input")

    with col2:
        st.image(mask,caption="Segmentation")

    with col3:
        st.image(overlay,caption="Overlay")

    st.subheader("Infrastructure Statistics")

    stats = calculate_percentages(pred)

    cols = st.columns(4)

    i = 0

    for cls,val in stats.items():

        cols[i%4].metric(
            cls,
            f"{val}%"
        )

        i += 1