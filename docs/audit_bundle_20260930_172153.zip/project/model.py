import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModel

NUM_CLASSES = 8


class ResidualConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()

        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),

            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch)
        )

        self.skip = (
            nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, bias=False),
                nn.BatchNorm2d(out_ch)
            )
            if in_ch != out_ch else nn.Identity()
        )

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        return self.relu(self.conv(x) + self.skip(x))


class ASPP(nn.Module):
    def __init__(self, in_ch, out_ch, rates=(6, 12, 18)):
        super().__init__()

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

        self.dilated = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(
                    in_ch,
                    out_ch,
                    3,
                    padding=r,
                    dilation=r,
                    bias=False
                ),
                nn.BatchNorm2d(out_ch),
                nn.ReLU(inplace=True)
            )
            for r in rates
        ])

        self.pool = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )

        n = len(rates) + 2

        self.project = nn.Sequential(
            nn.Conv2d(out_ch * n, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Dropout2d(0.1)
        )

    def forward(self, x):

        H, W = x.shape[-2:]

        out = [self.conv1(x)]

        for d in self.dilated:
            out.append(d(x))

        gp = F.interpolate(
            self.pool(x),
            size=(H, W),
            mode="bilinear",
            align_corners=False
        )

        out.append(gp)

        return self.project(torch.cat(out, dim=1))


class FPNFuse(nn.Module):
    def __init__(self, encoder_dim=768, fpn_dim=256):
        super().__init__()

        self.lat = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(
                    encoder_dim,
                    fpn_dim,
                    1,
                    bias=False
                ),
                nn.BatchNorm2d(fpn_dim),
                nn.ReLU(inplace=True)
            )
            for _ in range(4)
        ])

        self.fuse = nn.Sequential(
            nn.Conv2d(
                fpn_dim * 4,
                fpn_dim * 2,
                1,
                bias=False
            ),
            nn.BatchNorm2d(fpn_dim * 2),
            nn.ReLU(inplace=True)
        )

    def forward(self, feats):

        H, W = feats[0].shape[-2:]

        outs = []

        for i, f in enumerate(feats):

            x = self.lat[i](f)

            if x.shape[-2:] != (H, W):
                x = F.interpolate(
                    x,
                    size=(H, W),
                    mode="bilinear",
                    align_corners=False
                )

            outs.append(x)

        return self.fuse(torch.cat(outs, dim=1))


class StrongDINOv2Seg(nn.Module):

    def __init__(self):

        super().__init__()

        self.patch_size = 14

        self.encoder = AutoModel.from_pretrained(
            "facebook/dinov2-base",
            output_hidden_states=True
        )

        self.fpn = FPNFuse(
            encoder_dim=768,
            fpn_dim=256
        )

        self.aspp = ASPP(
            in_ch=512,
            out_ch=256
        )

        self.up1 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = ResidualConvBlock(256, 256)

        self.up2 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = ResidualConvBlock(256, 128)

        self.up3 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = ResidualConvBlock(128, 64)

        self.up4 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec4 = ResidualConvBlock(64, 32)

        self.seg_head = nn.Conv2d(32, NUM_CLASSES, 1)

    def _to_map(self, hidden, H, W):

        x = hidden[:, 1:, :]

        B, N, C = x.shape

        Hp = H // self.patch_size
        Wp = W // self.patch_size

        return x.permute(0, 2, 1).reshape(B, C, Hp, Wp)

    def forward(self, x):

        B, _, H, W = x.shape

        enc = self.encoder(pixel_values=x, output_hidden_states=True)

        layers = enc.hidden_states

        f3 = self._to_map(layers[3], H, W)
        f6 = self._to_map(layers[6], H, W)
        f9 = self._to_map(layers[9], H, W)
        f12 = self._to_map(layers[12], H, W)

        neck = self.aspp(
            self.fpn([f3, f6, f9, f12])
        )

        d1 = self.dec1(self.up1(neck))
        d2 = self.dec2(self.up2(d1))
        d3 = self.dec3(self.up3(d2))
        d4 = self.dec4(self.up4(d3))

        d4 = F.interpolate(
            d4,
            size=(H, W),
            mode="bilinear",
            align_corners=False
        )

        return self.seg_head(d4)