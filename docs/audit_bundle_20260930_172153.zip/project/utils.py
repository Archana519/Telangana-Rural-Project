import numpy as np

IMAGE_SIZE = 560

LOVE_DA_COLORS = {
    0:(0,0,0),
    1:(255,255,255),
    2:(255,0,0),
    3:(255,255,0),
    4:(0,0,255),
    5:(139,69,19),
    6:(0,255,0),
    7:(0,128,0)
}

CLASS_NAMES = {
    0:"Ignore",
    1:"Background",
    2:"Building",
    3:"Road",
    4:"Water",
    5:"Barren",
    6:"Forest",
    7:"Agriculture"
}


def colorize_mask(mask):

    h,w = mask.shape

    rgb = np.zeros((h,w,3),dtype=np.uint8)

    for cls,color in LOVE_DA_COLORS.items():
        rgb[mask==cls] = color

    return rgb


def calculate_percentages(mask):

    total = mask.size

    stats = {}

    unique,counts = np.unique(mask,return_counts=True)

    for u,c in zip(unique,counts):

        stats[CLASS_NAMES[int(u)]] = round(
            (c/total)*100,
            2
        )

    return stats