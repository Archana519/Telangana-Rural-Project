"""
Module 2: GIS & Connectivity Analysis
=======================================
Smart Village Infrastructure Analysis Pipeline
M.Tech Project - DINOv2 Semantic Segmentation Post-Processing

Author: [Your Name]
Description:
    - Converts road skeleton to NetworkX graph
    - Finds nearest road for each building
    - Determines road connectivity per building
    - Generates A* / Dijkstra proposed road paths for unconnected buildings
    - Computes road accessibility scores
    - Assigns building priority (Hospital > School > Govt > Residential)
    - Produces GIS-style connectivity statistics
"""

import cv2
import numpy as np
import networkx as nx
from scipy.spatial import KDTree
from typing import List, Tuple, Dict, Optional
import logging
import math

from module1_extraction import (
    Building, RoadNetwork,
    extract_buildings, extract_road_network, generate_synthetic_mask
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ─── Priority Configuration ───────────────────────────────────────────────────

PRIORITY_LEVELS = {
    "Hospital":           1,   # Highest
    "School":             2,
    "Government Office":  2,
    "Residential":        3,   # Normal
}

PRIORITY_COLORS = {
    "Hospital":           (0, 0, 255),    # Red (BGR)
    "School":             (0, 128, 255),  # Orange
    "Government Office":  (0, 200, 200),  # Yellow
    "Residential":        (200, 200, 200),# White-gray
}

# ─── Graph Builder ────────────────────────────────────────────────────────────

def build_road_graph(road_network: RoadNetwork,
                     downsample: int = 3) -> Tuple[nx.Graph, KDTree, List]:
    """
    Convert the road skeleton to a NetworkX graph.

    Strategy:
        - Each skeleton pixel becomes a node (row, col)
        - 8-connected neighbors become edges with Euclidean weight
        - Downsampling reduces graph size for large images

    Args:
        road_network: RoadNetwork object with skeleton
        downsample: Keep every Nth skeleton pixel as a node (1 = no downsampling)

    Returns:
        (graph, kdtree, node_list)
        - graph: NetworkX undirected weighted graph
        - kdtree: KDTree built on node coordinates for fast nearest-neighbor
        - node_list: List of (row, col) tuples corresponding to graph nodes
    """
    skeleton = road_network.skeleton
    pixels = road_network.pixel_coords  # List of (row, col)

    if not pixels:
        logger.warning("Road skeleton is empty. Cannot build graph.")
        return nx.Graph(), None, []

    # Downsample node set
    sampled = pixels[::downsample]

    G = nx.Graph()
    node_set = set(sampled)
    node_list = list(sampled)

    # Add nodes
    for idx, (r, c) in enumerate(node_list):
        G.add_node(idx, pos=(c, r))  # pos = (x, y) for visualization

    # Build spatial index for fast neighbor lookup
    coords = np.array(node_list)  # shape (N, 2): [[row, col], ...]
    kdtree = KDTree(coords)

    # Add edges: connect nodes within sqrt(2)*downsample pixel radius
    radius = math.sqrt(2) * downsample * 1.5
    pairs = kdtree.query_pairs(r=radius)
    for i, j in pairs:
        ri, ci = node_list[i]
        rj, cj = node_list[j]
        dist = math.hypot(ri - rj, ci - cj)
        G.add_edge(i, j, weight=dist)

    logger.info(
        f"Road graph built: {G.number_of_nodes()} nodes, "
        f"{G.number_of_edges()} edges (downsample={downsample})"
    )
    return G, kdtree, node_list


# ─── Connectivity Analysis ────────────────────────────────────────────────────

CONNECT_THRESHOLD_PX = 15  # Max distance (pixels) to consider a building "connected"

def analyze_connectivity(buildings: List[Building],
                         road_graph: nx.Graph,
                         road_kdtree: KDTree,
                         road_nodes: List[Tuple[int, int]],
                         connect_threshold: int = CONNECT_THRESHOLD_PX
                         ) -> List[Building]:
    """
    For each building, find the nearest road node and determine connectivity.

    A building is CONNECTED if its centroid's nearest road node is within
    `connect_threshold` pixels.

    Args:
        buildings: List of Building objects (modified in-place)
        road_graph: NetworkX road graph
        road_kdtree: KDTree of road node coordinates
        road_nodes: List of (row, col) road node positions
        connect_threshold: Pixel distance threshold for connectivity

    Returns:
        Updated list of Building objects
    """
    if road_kdtree is None:
        logger.warning("No road KDTree. All buildings marked unconnected.")
        return buildings

    for b in buildings:
        cx, cy = b.centroid  # (x=col, y=row)
        query_point = [cy, cx]  # (row, col) for KDTree

        dist, idx = road_kdtree.query(query_point)
        nearest_node = road_nodes[idx]
        b.nearest_road_point = (nearest_node[1], nearest_node[0])  # (col, row) = (x,y)
        b.distance_to_road = float(dist)

        # Connected if close enough to road
        b.connected = dist <= connect_threshold

        # Accessibility score: 0–100 (higher = better access)
        b.accessibility_score = max(0.0, 100.0 * (1.0 - dist / 200.0))

    connected = sum(1 for b in buildings if b.connected)
    logger.info(
        f"Connectivity: {connected}/{len(buildings)} buildings connected "
        f"(threshold={connect_threshold}px)"
    )
    return buildings


def assign_priorities(buildings: List[Building],
                      priority_map: Optional[Dict[int, str]] = None
                      ) -> List[Building]:
    """
    Assign building types and priorities.

    In a real system, priority_map would come from:
      - OSM tags merged with segmentation
      - Manual annotation
      - ML classification of building appearance

    For demonstration, we assign types based on building size and id heuristics.

    Args:
        buildings: List of Building objects (modified in-place)
        priority_map: Optional dict {building_id: priority_label}

    Returns:
        Updated Building list
    """
    if priority_map:
        for b in buildings:
            b.priority = priority_map.get(b.id, "Residential")
        return buildings

    # Heuristic assignment for demo:
    # Largest building = Hospital, second largest = School, etc.
    sorted_by_area = sorted(buildings, key=lambda b: b.area, reverse=True)
    if len(sorted_by_area) >= 1:
        sorted_by_area[0].priority = "Hospital"
    if len(sorted_by_area) >= 2:
        sorted_by_area[1].priority = "School"
    if len(sorted_by_area) >= 3:
        sorted_by_area[2].priority = "Government Office"
    for b in sorted_by_area[3:]:
        b.priority = "Residential"

    return buildings


# ─── Proposed Road Path Generation ───────────────────────────────────────────

def generate_proposed_roads(buildings: List[Building],
                            road_graph: nx.Graph,
                            road_kdtree: KDTree,
                            road_nodes: List[Tuple[int, int]],
                            mask_shape: Tuple[int, int],
                            ) -> Dict[int, List[Tuple[int, int]]]:
    """
    For each unconnected building, compute the shortest path to the
    nearest connected road node using Dijkstra (A* approximation via networkx).

    The path is returned as a list of (x, y) pixel waypoints.

    Strategy:
        1. Find the building centroid
        2. Find its nearest graph node (even if far)
        3. Find the nearest CONNECTED graph node to any connected building
        4. Run nx.shortest_path (Dijkstra by default) between them
        5. Interpolate smooth pixel path

    Args:
        buildings: List of Building objects
        road_graph: NetworkX road graph
        road_kdtree: KDTree of road nodes
        road_nodes: List of (row, col) node coords
        mask_shape: (H, W) of the segmentation mask

    Returns:
        Dict mapping building_id → list of (x, y) waypoints (proposed road path)
    """
    proposed_paths: Dict[int, List[Tuple[int, int]]] = {}
    unconnected = [b for b in buildings if not b.connected]

    if not unconnected:
        logger.info("All buildings are connected. No proposed roads needed.")
        return proposed_paths

    if road_graph.number_of_nodes() == 0:
        logger.warning("Empty road graph. Cannot generate proposed roads.")
        return proposed_paths

    # Determine which graph nodes are "connected" (near a connected building)
    connected_node_indices = set()
    for b in buildings:
        if b.connected and b.nearest_road_point is not None:
            nx_pt, ny_pt = b.nearest_road_point  # (x, y)
            dist, idx = road_kdtree.query([ny_pt, nx_pt])
            connected_node_indices.add(idx)

    # Fallback: if no connected buildings, use all nodes
    if not connected_node_indices:
        connected_node_indices = set(road_graph.nodes())

    for b in unconnected:
        cx, cy = b.centroid  # (x=col, y=row)
        # Find nearest graph node to building centroid
        dist_b, src_idx = road_kdtree.query([cy, cx])

        # Find nearest connected node
        best_target = None
        best_dist = float("inf")
        for t_idx in connected_node_indices:
            tr, tc = road_nodes[t_idx]
            d = math.hypot(tr - cy, tc - cx)
            if d < best_dist:
                best_dist = d
                best_target = t_idx

        if best_target is None or src_idx == best_target:
            continue

        # Ensure both nodes exist in graph
        if src_idx not in road_graph or best_target not in road_graph:
            continue

        try:
            # A*-style with Euclidean heuristic
            def heuristic(u, v):
                r1, c1 = road_nodes[u]
                r2, c2 = road_nodes[v]
                return math.hypot(r1 - r2, c1 - c2)

            path_nodes = nx.astar_path(
                road_graph, src_idx, best_target,
                heuristic=heuristic, weight="weight"
            )
            # Convert node indices to (x, y) pixel coords
            waypoints = [(road_nodes[n][1], road_nodes[n][0]) for n in path_nodes]

            # Prepend building centroid
            waypoints = [b.centroid] + waypoints
            proposed_paths[b.id] = waypoints

        except (nx.NetworkXNoPath, nx.NodeNotFound):
            # If no path exists in graph, draw a straight line
            if b.nearest_road_point:
                proposed_paths[b.id] = [b.centroid, b.nearest_road_point]

    logger.info(f"Generated {len(proposed_paths)} proposed road paths.")
    return proposed_paths


# ─── Statistics ───────────────────────────────────────────────────────────────

def compute_statistics(buildings: List[Building],
                       road_network: RoadNetwork,
                       proposed_paths: Dict) -> Dict:
    """
    Compute GIS-style connectivity statistics.

    Args:
        buildings: Analyzed building list
        road_network: RoadNetwork object
        proposed_paths: Dict of proposed road paths

    Returns:
        Statistics dictionary
    """
    total = len(buildings)
    connected = sum(1 for b in buildings if b.connected)
    unconnected = total - connected
    pct = (connected / total * 100) if total else 0.0

    distances = [b.distance_to_road for b in buildings if b.distance_to_road < float("inf")]
    avg_dist = float(np.mean(distances)) if distances else 0.0

    # Road network length in pixels (skeleton pixel count ≈ length)
    road_length_px = int(road_network.skeleton.sum() // 255)

    priority_counts = {}
    for b in buildings:
        priority_counts[b.priority] = priority_counts.get(b.priority, 0) + 1

    unconnected_by_priority = {}
    for b in buildings:
        if not b.connected:
            unconnected_by_priority[b.priority] = unconnected_by_priority.get(b.priority, 0) + 1

    stats = {
        "total_buildings":        total,
        "connected_buildings":    connected,
        "unconnected_buildings":  unconnected,
        "connectivity_pct":       round(pct, 2),
        "avg_distance_to_road":   round(avg_dist, 2),
        "road_length_px":         road_length_px,
        "proposed_roads_count":   len(proposed_paths),
        "priority_distribution":  priority_counts,
        "unconnected_by_priority":unconnected_by_priority,
    }

    logger.info("=== Connectivity Statistics ===")
    for k, v in stats.items():
        logger.info(f"  {k:30s}: {v}")

    return stats


# ─── Visualization ────────────────────────────────────────────────────────────

def visualize_connectivity(seg_mask: np.ndarray,
                           buildings: List[Building],
                           road_network: RoadNetwork,
                           proposed_paths: Dict[int, List],
                           save_path: Optional[str] = None) -> np.ndarray:
    """
    Visualize connectivity analysis:
    - Connected buildings → green
    - Unconnected buildings → red
    - Road network → gray
    - Proposed roads → blue dashed
    - Priority labels

    Args:
        seg_mask: Segmentation mask
        buildings: Analyzed buildings
        road_network: Road network
        proposed_paths: Proposed road paths
        save_path: Optional path to save visualization

    Returns:
        BGR visualization image
    """
    H, W = seg_mask.shape
    vis = np.zeros((H, W, 3), dtype=np.uint8)

    # Background terrain
    color_map = {
        0: (30, 30, 30), 1: (100, 80, 50), 2: (180, 180, 180),
        3: (180, 160, 120), 4: (30, 100, 30), 5: (180, 100, 50), 6: (80, 150, 50),
    }
    for label, color in color_map.items():
        vis[seg_mask == label] = color[::-1]

    # Draw road skeleton
    vis[road_network.skeleton > 0] = (150, 150, 150)

    # Draw buildings with connectivity color
    for b in buildings:
        color = (0, 200, 0) if b.connected else (0, 0, 220)  # BGR: green / red
        if b.contour.size > 0:
            cv2.drawContours(vis, [b.contour], -1, color, 2)
            # Fill with semi-transparent color (manual blend)
            mask_b = np.zeros((H, W), dtype=np.uint8)
            cv2.drawContours(mask_b, [b.contour], -1, 255, -1)
            vis[mask_b > 0] = (
                vis[mask_b > 0] * 0.4 + np.array(color, dtype=float) * 0.6
            ).astype(np.uint8)

        # Draw line to nearest road
        if b.nearest_road_point:
            line_color = (0, 180, 0) if b.connected else (0, 0, 180)
            cv2.line(vis, b.centroid, b.nearest_road_point, line_color, 1)

        # Priority icon / label
        p_color = PRIORITY_COLORS.get(b.priority, (255, 255, 255))
        cv2.circle(vis, b.centroid, 5, p_color[::-1], -1)
        cv2.putText(
            vis, b.priority[0],  # First letter: H/S/G/R
            (b.centroid[0] - 3, b.centroid[1] + 4),
            cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 0, 0), 1
        )

    # Draw proposed roads in blue
    for b_id, path in proposed_paths.items():
        for i in range(len(path) - 1):
            cv2.line(vis, path[i], path[i + 1], (255, 100, 0), 2)  # Blue

    # Legend
    _draw_legend(vis)

    if save_path:
        cv2.imwrite(save_path, vis)
        logger.info(f"Connectivity visualization saved → {save_path}")

    return vis


def _draw_legend(vis: np.ndarray):
    """Draw a simple legend overlay on the visualization."""
    items = [
        ((0, 200, 0),   "Connected Building"),
        ((0, 0, 220),   "Unconnected Building"),
        ((255, 100, 0), "Proposed Road"),
        ((150, 150, 150), "Road Network"),
    ]
    x0, y0 = 10, 10
    for i, (color, label) in enumerate(items):
        y = y0 + i * 18
        cv2.rectangle(vis, (x0, y), (x0 + 12, y + 12), color, -1)
        cv2.putText(vis, label, (x0 + 16, y + 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (230, 230, 230), 1)


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import matplotlib.pyplot as plt

    logger.info("=== Module 2: GIS & Connectivity Analysis ===")

    # Step 1: Generate/load mask
    mask = generate_synthetic_mask(512, 512)

    # Step 2: Extract
    buildings = extract_buildings(mask, min_area=50)
    road_net = extract_road_network(mask, skeletonize=True)

    # Step 3: Build road graph
    G, kdtree, nodes = build_road_graph(road_net, downsample=2)

    # Step 4: Analyze connectivity
    buildings = analyze_connectivity(buildings, G, kdtree, nodes, connect_threshold=20)

    # Step 5: Assign priorities
    buildings = assign_priorities(buildings)

    # Step 6: Generate proposed roads
    proposed = generate_proposed_roads(buildings, G, kdtree, nodes, mask.shape)

    # Step 7: Statistics
    stats = compute_statistics(buildings, road_net, proposed)

    # Step 8: Visualize
    vis = visualize_connectivity(mask, buildings, road_net, proposed,
                                 save_path="connectivity_output.png")

    print("\n=== Summary ===")
    for k, v in stats.items():
        print(f"  {k:35s}: {v}")

    plt.figure(figsize=(9, 9))
    plt.imshow(cv2.cvtColor(vis, cv2.COLOR_BGR2RGB))
    plt.title("Module 2 — GIS & Connectivity Analysis")
    plt.axis("off")
    plt.tight_layout()
    plt.show()
