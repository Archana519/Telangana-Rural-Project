"""
Module 3: Final Output — Smart Village Infrastructure Report
=============================================================
Smart Village Infrastructure Analysis Pipeline
M.Tech Project - DINOv2 Semantic Segmentation Post-Processing

Author: [Your Name]
Description:
    Generates:
    1. Village Infrastructure Map (roads, buildings, terrain, proposed roads)
    2. Road Connectivity Visualization (green/red/blue)
    3. Smart Rural Planning Dashboard (statistics panels)
    4. Exports: PNG map, PDF report, CSV statistics
    5. Pipeline integration function run_full_pipeline()
"""

import cv2
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for server/batch use
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.colors import ListedColormap
import pandas as pd
import os
import logging
from datetime import datetime
from typing import List, Dict, Optional, Tuple

from module1_extraction import (
    Building, RoadNetwork,
    extract_buildings, extract_road_network, generate_synthetic_mask
)
from module2_connectivity import (
    build_road_graph, analyze_connectivity, assign_priorities,
    generate_proposed_roads, compute_statistics
)

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ─── Color Palette ────────────────────────────────────────────────────────────
# All RGB tuples (matplotlib convention)

TERRAIN_COLORS_RGB = {
    0: (0.12, 0.12, 0.12),   # Background
    1: (0.65, 0.45, 0.25),   # Building - earth brown
    2: (0.75, 0.75, 0.75),   # Road - gray
    3: (0.80, 0.70, 0.55),   # Barren - tan
    4: (0.13, 0.55, 0.13),   # Forest - dark green
    5: (0.25, 0.41, 0.88),   # Water - royal blue
    6: (0.60, 0.80, 0.20),   # Agriculture - yellow-green
}

CONNECTIVITY_COLORS = {
    "connected":    "#27ae60",   # Green
    "unconnected":  "#e74c3c",   # Red
    "proposed_road":"#2980b9",   # Blue
    "road":         "#95a5a6",   # Gray
}

PRIORITY_COLORS_HEX = {
    "Hospital":          "#e74c3c",
    "School":            "#e67e22",
    "Government Office": "#f1c40f",
    "Residential":       "#bdc3c7",
}

DASHBOARD_BG   = "#0d1117"
DASHBOARD_CARD = "#161b22"
DASHBOARD_ACC  = "#238636"
DASHBOARD_TEXT = "#c9d1d9"


# ─── Map 1: Village Infrastructure Map ───────────────────────────────────────

def render_infrastructure_map(seg_mask: np.ndarray,
                               buildings: List[Building],
                               road_network: RoadNetwork,
                               proposed_paths: Dict,
                               save_path: Optional[str] = None,
                               dpi: int = 150) -> plt.Figure:
    """
    Render a full GIS-style village infrastructure map.

    Layers (bottom to top):
      1. Terrain classes (segmentation colorized)
      2. Road network (gray)
      3. Road skeleton (darker gray)
      4. Buildings (brown, labeled)
      5. Proposed roads (blue dashed)
      6. Legend + title

    Returns: matplotlib Figure
    """
    H, W = seg_mask.shape
    terrain_img = np.zeros((H, W, 3), dtype=np.float32)
    for label, color in TERRAIN_COLORS_RGB.items():
        terrain_img[seg_mask == label] = color

    fig, ax = plt.subplots(figsize=(12, 12), dpi=dpi)
    fig.patch.set_facecolor(DASHBOARD_BG)
    ax.set_facecolor(DASHBOARD_BG)

    # Layer 1: Terrain
    ax.imshow(terrain_img, interpolation="bilinear", alpha=0.9)

    # Layer 2: Road mask (semi-transparent overlay)
    road_overlay = np.zeros((H, W, 4), dtype=np.float32)
    road_overlay[road_network.mask > 0] = [0.75, 0.75, 0.75, 0.6]
    ax.imshow(road_overlay, interpolation="nearest")

    # Layer 3: Skeleton highlight
    skel_overlay = np.zeros((H, W, 4), dtype=np.float32)
    skel_overlay[road_network.skeleton > 0] = [1.0, 0.95, 0.4, 0.8]
    ax.imshow(skel_overlay, interpolation="nearest")

    # Layer 4: Buildings
    for b in buildings:
        p_color = PRIORITY_COLORS_HEX.get(b.priority, "#bdc3c7")
        if b.contour.size > 0:
            pts = b.contour.reshape(-1, 2)
            poly = plt.Polygon(pts, closed=True,
                               facecolor=p_color, edgecolor="white",
                               linewidth=0.8, alpha=0.85, zorder=3)
            ax.add_patch(poly)
        ax.annotate(
            b.priority[0],
            xy=(b.centroid[0], b.centroid[1]),
            fontsize=5, color="black", ha="center", va="center",
            fontweight="bold", zorder=5
        )

    # Layer 5: Proposed roads
    for b_id, path in proposed_paths.items():
        if len(path) >= 2:
            xs = [p[0] for p in path]
            ys = [p[1] for p in path]
            ax.plot(xs, ys, "--", color=CONNECTIVITY_COLORS["proposed_road"],
                    linewidth=1.8, alpha=0.9, zorder=4)
            ax.plot(xs[0], ys[0], "o",
                    color=CONNECTIVITY_COLORS["proposed_road"],
                    markersize=4, zorder=5)

    # Legend
    legend_patches = [
        mpatches.Patch(color=(0.13, 0.55, 0.13), label="Forest"),
        mpatches.Patch(color=(0.25, 0.41, 0.88), label="Water"),
        mpatches.Patch(color=(0.60, 0.80, 0.20), label="Agriculture"),
        mpatches.Patch(color=(0.80, 0.70, 0.55), label="Barren"),
        mpatches.Patch(color="#e74c3c",           label="Hospital"),
        mpatches.Patch(color="#e67e22",           label="School"),
        mpatches.Patch(color="#f1c40f",           label="Gov. Office"),
        mpatches.Patch(color="#bdc3c7",           label="Residential"),
        mpatches.Patch(color="#2980b9",           label="Proposed Road"),
        mpatches.Patch(color="#f0e040",           label="Road Skeleton"),
    ]
    legend = ax.legend(
        handles=legend_patches,
        loc="lower left", fontsize=7,
        facecolor=DASHBOARD_CARD, edgecolor="#30363d",
        labelcolor=DASHBOARD_TEXT, framealpha=0.92,
        title="Legend", title_fontsize=8,
    )
    legend.get_title().set_color(DASHBOARD_TEXT)

    ax.set_title(
        "Smart Village Infrastructure Map",
        color=DASHBOARD_TEXT, fontsize=14, fontweight="bold", pad=12
    )
    ax.axis("off")
    fig.tight_layout(pad=0.5)

    if save_path:
        fig.savefig(save_path, dpi=dpi, bbox_inches="tight",
                    facecolor=fig.get_facecolor())
        logger.info(f"Infrastructure map saved → {save_path}")

    return fig


# ─── Map 2: Road Connectivity Visualization ──────────────────────────────────

def render_connectivity_map(seg_mask: np.ndarray,
                             buildings: List[Building],
                             road_network: RoadNetwork,
                             proposed_paths: Dict,
                             save_path: Optional[str] = None,
                             dpi: int = 150) -> plt.Figure:
    """
    Render focused connectivity map.
    Connected = green, Unconnected = red, Proposed = blue.
    """
    H, W = seg_mask.shape
    terrain_img = np.zeros((H, W, 3), dtype=np.float32)
    for label, color in TERRAIN_COLORS_RGB.items():
        terrain_img[seg_mask == label] = color
    terrain_img = terrain_img * 0.4  # Dim background

    fig, ax = plt.subplots(figsize=(10, 10), dpi=dpi)
    fig.patch.set_facecolor(DASHBOARD_BG)
    ax.set_facecolor(DASHBOARD_BG)

    ax.imshow(terrain_img, interpolation="bilinear")

    # Road network
    road_rgba = np.zeros((H, W, 4), dtype=np.float32)
    road_rgba[road_network.mask > 0] = [0.7, 0.7, 0.7, 0.5]
    ax.imshow(road_rgba)

    # Buildings
    for b in buildings:
        color = CONNECTIVITY_COLORS["connected"] if b.connected \
                else CONNECTIVITY_COLORS["unconnected"]
        marker = "o" if b.connected else "^"
        ax.plot(b.centroid[0], b.centroid[1], marker,
                color=color, markersize=7, markeredgecolor="white",
                markeredgewidth=0.5, zorder=5)
        if b.nearest_road_point:
            ax.plot(
                [b.centroid[0], b.nearest_road_point[0]],
                [b.centroid[1], b.nearest_road_point[1]],
                "-", color=color, linewidth=0.6, alpha=0.5, zorder=3
            )

    # Proposed roads
    for b_id, path in proposed_paths.items():
        if len(path) >= 2:
            xs = [p[0] for p in path]
            ys = [p[1] for p in path]
            ax.plot(xs, ys, "--",
                    color=CONNECTIVITY_COLORS["proposed_road"],
                    linewidth=2.0, alpha=0.9, zorder=4, label="Proposed Road")

    # Legend
    legend_items = [
        plt.Line2D([0], [0], marker="o", color="w",
                   markerfacecolor=CONNECTIVITY_COLORS["connected"],
                   markersize=8, label="Connected Building"),
        plt.Line2D([0], [0], marker="^", color="w",
                   markerfacecolor=CONNECTIVITY_COLORS["unconnected"],
                   markersize=8, label="Unconnected Building"),
        plt.Line2D([0], [0], linestyle="--",
                   color=CONNECTIVITY_COLORS["proposed_road"],
                   linewidth=2, label="Proposed Road"),
    ]
    legend = ax.legend(
        handles=legend_items, loc="upper right", fontsize=9,
        facecolor=DASHBOARD_CARD, edgecolor="#30363d",
        labelcolor=DASHBOARD_TEXT, framealpha=0.9
    )

    ax.set_title(
        "Road Connectivity Analysis",
        color=DASHBOARD_TEXT, fontsize=13, fontweight="bold", pad=10
    )
    ax.axis("off")
    fig.tight_layout(pad=0.5)

    if save_path:
        fig.savefig(save_path, dpi=dpi, bbox_inches="tight",
                    facecolor=fig.get_facecolor())
        logger.info(f"Connectivity map saved → {save_path}")

    return fig


# ─── Dashboard ────────────────────────────────────────────────────────────────

def render_dashboard(stats: Dict,
                     buildings: List[Building],
                     connectivity_fig: plt.Figure,
                     save_path: Optional[str] = None,
                     dpi: int = 120) -> plt.Figure:
    """
    Render a Smart Rural Planning Dashboard.

    Layout:
    ┌──────────────────────────────────────────────────┐
    │  HEADER                                          │
    ├──────────┬──────────┬──────────┬─────────────────┤
    │ Total    │Connected │Unconn.   │Connectivity %   │
    ├──────────┴──────────┴──────────┴─────────────────┤
    │                Connectivity Map                   │
    ├──────────────────┬───────────────────────────────┤
    │  Priority Chart  │  Distance Histogram            │
    └──────────────────┴───────────────────────────────┘
    """
    fig = plt.figure(figsize=(16, 14), dpi=dpi)
    fig.patch.set_facecolor(DASHBOARD_BG)

    gs = gridspec.GridSpec(
        4, 4,
        figure=fig,
        height_ratios=[0.5, 0.5, 3, 2.5],
        hspace=0.35, wspace=0.3
    )

    # ── Header ──────────────────────────────────────────
    ax_header = fig.add_subplot(gs[0, :])
    ax_header.set_facecolor(DASHBOARD_CARD)
    ax_header.set_xlim(0, 1)
    ax_header.set_ylim(0, 1)
    ax_header.axis("off")
    ax_header.text(
        0.5, 0.65, "🛰  Smart Village Infrastructure Planning Dashboard",
        ha="center", va="center",
        fontsize=16, fontweight="bold", color=DASHBOARD_TEXT,
        fontfamily="DejaVu Sans"
    )
    ts = datetime.now().strftime("%d %B %Y, %H:%M")
    ax_header.text(
        0.5, 0.22, f"Generated: {ts}  |  DINOv2 Segmentation Pipeline",
        ha="center", va="center",
        fontsize=8, color="#8b949e"
    )

    # ── KPI Cards ────────────────────────────────────────
    kpis = [
        ("Total Buildings",       stats["total_buildings"],        "#58a6ff"),
        ("Connected",             stats["connected_buildings"],     "#3fb950"),
        ("Unconnected",           stats["unconnected_buildings"],   "#f85149"),
        ("Connectivity %",        f"{stats['connectivity_pct']:.1f}%", "#d2a8ff"),
    ]
    for col, (label, value, color) in enumerate(kpis):
        ax = fig.add_subplot(gs[1, col])
        ax.set_facecolor(DASHBOARD_CARD)
        ax.set_xlim(0, 1); ax.set_ylim(0, 1)
        ax.axis("off")
        ax.text(0.5, 0.70, str(value), ha="center", va="center",
                fontsize=22, fontweight="bold", color=color)
        ax.text(0.5, 0.18, label, ha="center", va="center",
                fontsize=8, color="#8b949e")
        for spine in ["top", "bottom", "left", "right"]:
            ax.spines[spine].set_visible(False)

    # ── Connectivity Map (center large panel) ────────────
    ax_map = fig.add_subplot(gs[2, :])
    ax_map.set_facecolor(DASHBOARD_BG)
    ax_map.axis("off")
    # Embed the connectivity figure as an image
    connectivity_fig.canvas.draw()
    map_img = np.asarray(connectivity_fig.canvas.buffer_rgba())[..., :3].copy()
    ax_map.imshow(map_img, aspect="auto")
    ax_map.set_title("Road Connectivity Map", color=DASHBOARD_TEXT,
                     fontsize=10, pad=4)

    # ── Priority Distribution Chart ───────────────────────
    ax_prio = fig.add_subplot(gs[3, :2])
    ax_prio.set_facecolor(DASHBOARD_CARD)
    priority_counts = stats.get("priority_distribution", {})
    if priority_counts:
        labels = list(priority_counts.keys())
        values = list(priority_counts.values())
        bar_colors = [PRIORITY_COLORS_HEX.get(l, "#8b949e") for l in labels]
        bars = ax_prio.bar(labels, values, color=bar_colors, edgecolor="#30363d",
                           linewidth=0.8)
        for bar, val in zip(bars, values):
            ax_prio.text(
                bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
                str(val), ha="center", va="bottom",
                fontsize=9, color=DASHBOARD_TEXT, fontweight="bold"
            )
    ax_prio.set_facecolor(DASHBOARD_CARD)
    ax_prio.set_title("Building Priority Distribution", color=DASHBOARD_TEXT,
                      fontsize=10, pad=6)
    ax_prio.tick_params(colors=DASHBOARD_TEXT, labelsize=8)
    ax_prio.set_ylabel("Count", color=DASHBOARD_TEXT, fontsize=8)
    for spine in ax_prio.spines.values():
        spine.set_edgecolor("#30363d")
    ax_prio.set_facecolor(DASHBOARD_CARD)

    # ── Distance Histogram ────────────────────────────────
    ax_hist = fig.add_subplot(gs[3, 2:])
    ax_hist.set_facecolor(DASHBOARD_CARD)
    distances = [b.distance_to_road for b in buildings
                 if b.distance_to_road < float("inf")]
    if distances:
        n, bins, patches = ax_hist.hist(
            distances, bins=15, color="#388bfd", edgecolor="#30363d", linewidth=0.6
        )
        # Color bars by distance range
        for patch, left in zip(patches, bins[:-1]):
            if left < 20:
                patch.set_facecolor("#3fb950")   # Green = close
            elif left < 50:
                patch.set_facecolor("#d29922")   # Yellow = medium
            else:
                patch.set_facecolor("#f85149")   # Red = far

        avg = stats["avg_distance_to_road"]
        ax_hist.axvline(avg, color="#d2a8ff", linestyle="--", linewidth=1.2)
        ax_hist.text(avg + 1, n.max() * 0.85,
                     f"Avg: {avg:.1f}px",
                     color="#d2a8ff", fontsize=8)

    ax_hist.set_title("Distance to Road Distribution", color=DASHBOARD_TEXT,
                      fontsize=10, pad=6)
    ax_hist.tick_params(colors=DASHBOARD_TEXT, labelsize=8)
    ax_hist.set_xlabel("Distance (pixels)", color=DASHBOARD_TEXT, fontsize=8)
    ax_hist.set_ylabel("Buildings", color=DASHBOARD_TEXT, fontsize=8)
    for spine in ax_hist.spines.values():
        spine.set_edgecolor("#30363d")
    ax_hist.set_facecolor(DASHBOARD_CARD)

    # ── Footer stats bar ─────────────────────────────────
    footer_text = (
        f"Road Network Length: {stats['road_length_px']} px  |  "
        f"Proposed Roads: {stats['proposed_roads_count']}  |  "
        f"Avg Distance to Road: {stats['avg_distance_to_road']} px"
    )
    fig.text(0.5, 0.01, footer_text, ha="center", va="bottom",
             fontsize=8, color="#8b949e")

    plt.suptitle("")  # Clear auto title
    if save_path:
        fig.savefig(save_path, dpi=dpi, bbox_inches="tight",
                    facecolor=fig.get_facecolor())
        logger.info(f"Dashboard saved → {save_path}")

    return fig


# ─── CSV Export ───────────────────────────────────────────────────────────────

def export_csv(buildings: List[Building],
               stats: Dict,
               output_dir: str = ".") -> Tuple[str, str]:
    """
    Export building data and summary statistics to CSV files.

    Returns: (buildings_csv_path, stats_csv_path)
    """
    os.makedirs(output_dir, exist_ok=True)

    # Buildings table
    rows = []
    for b in buildings:
        rows.append({
            "building_id":        b.id,
            "centroid_x":         b.centroid[0],
            "centroid_y":         b.centroid[1],
            "area_px":            b.area,
            "priority":           b.priority,
            "connected":          b.connected,
            "distance_to_road_px":round(b.distance_to_road, 2),
            "accessibility_score":round(b.accessibility_score, 2),
            "nearest_road_x":     b.nearest_road_point[0] if b.nearest_road_point else None,
            "nearest_road_y":     b.nearest_road_point[1] if b.nearest_road_point else None,
        })
    df_buildings = pd.DataFrame(rows)
    b_path = os.path.join(output_dir, "buildings_connectivity.csv")
    df_buildings.to_csv(b_path, index=False)
    logger.info(f"Buildings CSV saved → {b_path}")

    # Summary statistics
    flat_stats = {
        k: str(v) for k, v in stats.items()
        if not isinstance(v, dict)
    }
    flat_stats["timestamp"] = datetime.now().isoformat()
    df_stats = pd.DataFrame([flat_stats]).T.reset_index()
    df_stats.columns = ["Metric", "Value"]
    s_path = os.path.join(output_dir, "connectivity_statistics.csv")
    df_stats.to_csv(s_path, index=False)
    logger.info(f"Statistics CSV saved → {s_path}")

    return b_path, s_path


# ─── PDF Report ───────────────────────────────────────────────────────────────

def export_pdf_report(infra_fig: plt.Figure,
                      connectivity_fig: plt.Figure,
                      dashboard_fig: plt.Figure,
                      stats: Dict,
                      output_path: str) -> str:
    """
    Combine all figures into a multi-page PDF report.

    Pages:
    1. Title + Summary Statistics
    2. Village Infrastructure Map
    3. Road Connectivity Map
    4. Smart Rural Planning Dashboard
    """
    from matplotlib.backends.backend_pdf import PdfPages

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    with PdfPages(output_path) as pdf:
        # Page 1: Title page + stats
        fig_title = plt.figure(figsize=(11, 8.5))
        fig_title.patch.set_facecolor(DASHBOARD_BG)
        ax = fig_title.add_subplot(111)
        ax.set_facecolor(DASHBOARD_BG)
        ax.axis("off")

        ax.text(0.5, 0.92, "Smart Village Infrastructure Analysis",
                ha="center", va="top", fontsize=22, fontweight="bold",
                color=DASHBOARD_TEXT, transform=ax.transAxes)
        ax.text(0.5, 0.82, "DINOv2-Based Semantic Segmentation — M.Tech Project",
                ha="center", va="top", fontsize=13, color="#8b949e",
                transform=ax.transAxes)
        ax.text(0.5, 0.74,
                datetime.now().strftime("Report Generated: %d %B %Y, %H:%M"),
                ha="center", va="top", fontsize=10, color="#8b949e",
                transform=ax.transAxes)

        # Stats table
        table_data = [
            ["Total Buildings",         str(stats["total_buildings"])],
            ["Connected Buildings",      str(stats["connected_buildings"])],
            ["Unconnected Buildings",    str(stats["unconnected_buildings"])],
            ["Connectivity Percentage",  f"{stats['connectivity_pct']}%"],
            ["Avg Distance to Road",     f"{stats['avg_distance_to_road']} px"],
            ["Road Network Length",      f"{stats['road_length_px']} px"],
            ["Proposed Roads",           str(stats["proposed_roads_count"])],
        ]
        table = ax.table(
            cellText=table_data,
            colLabels=["Metric", "Value"],
            loc="center",
            cellLoc="left",
            bbox=[0.15, 0.15, 0.70, 0.52]
        )
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        for (row, col), cell in table.get_celld().items():
            if row == 0:
                cell.set_facecolor("#238636")
                cell.set_text_props(color="white", fontweight="bold")
            elif row % 2 == 0:
                cell.set_facecolor("#161b22")
                cell.set_text_props(color=DASHBOARD_TEXT)
            else:
                cell.set_facecolor("#0d1117")
                cell.set_text_props(color=DASHBOARD_TEXT)
            cell.set_edgecolor("#30363d")

        pdf.savefig(fig_title, bbox_inches="tight",
                    facecolor=fig_title.get_facecolor())
        plt.close(fig_title)

        # Page 2: Infrastructure Map
        pdf.savefig(infra_fig, bbox_inches="tight",
                    facecolor=infra_fig.get_facecolor())

        # Page 3: Connectivity Map
        pdf.savefig(connectivity_fig, bbox_inches="tight",
                    facecolor=connectivity_fig.get_facecolor())

        # Page 4: Dashboard
        pdf.savefig(dashboard_fig, bbox_inches="tight",
                    facecolor=dashboard_fig.get_facecolor())

        d = pdf.infodict()
        d["Title"]   = "Smart Village Infrastructure Report"
        d["Author"]  = "DINOv2 Segmentation Pipeline"
        d["Subject"] = "M.Tech GIS Connectivity Analysis"
        d["Keywords"]= "DINOv2, Segmentation, GIS, Road Connectivity"

    logger.info(f"PDF report saved → {output_path}")
    return output_path


# ─── Full Pipeline Integration ────────────────────────────────────────────────

def run_full_pipeline(seg_mask: np.ndarray,
                      output_dir: str = "smart_village_output",
                      priority_map: Optional[Dict] = None,
                      connect_threshold: int = 20,
                      downsample: int = 2) -> Dict:
    """
    Run the complete Smart Village Infrastructure Analysis pipeline.

    Steps:
        Step 1 → Segmentation Output (mask input)
        Step 2 → Connectivity Analysis
        Step 3 → Final Smart Village Infrastructure Report

    Args:
        seg_mask:          2D numpy array from DINOv2 segmentation (H x W)
        output_dir:        Directory to save all outputs
        priority_map:      Optional {building_id: priority_label}
        connect_threshold: Pixel distance threshold for connectivity
        downsample:        Road graph node downsampling factor

    Returns:
        Dictionary containing all results and output file paths
    """
    os.makedirs(output_dir, exist_ok=True)
    logger.info("=" * 60)
    logger.info("  SMART VILLAGE INFRASTRUCTURE ANALYSIS PIPELINE")
    logger.info("=" * 60)

    # ── STEP 1: Extraction ────────────────────────────────
    logger.info("\n[Step 1/4] Extracting buildings and road network...")
    buildings   = extract_buildings(seg_mask, min_area=50)
    road_net    = extract_road_network(seg_mask, skeletonize=True)

    # ── STEP 2: Graph & Connectivity ──────────────────────
    logger.info("\n[Step 2/4] Building road graph & analysing connectivity...")
    G, kdtree, nodes = build_road_graph(road_net, downsample=downsample)
    buildings        = analyze_connectivity(buildings, G, kdtree, nodes,
                                            connect_threshold=connect_threshold)
    buildings        = assign_priorities(buildings, priority_map)
    proposed_paths   = generate_proposed_roads(buildings, G, kdtree, nodes,
                                               seg_mask.shape)
    stats            = compute_statistics(buildings, road_net, proposed_paths)

    # ── STEP 3: Render Outputs ────────────────────────────
    logger.info("\n[Step 3/4] Rendering maps and dashboard...")

    infra_path    = os.path.join(output_dir, "village_infrastructure_map.png")
    conn_path     = os.path.join(output_dir, "road_connectivity_map.png")
    dash_path     = os.path.join(output_dir, "smart_village_dashboard.png")
    pdf_path      = os.path.join(output_dir, "smart_village_report.pdf")
    b_csv, s_csv  = export_csv(buildings, stats, output_dir)

    infra_fig    = render_infrastructure_map(seg_mask, buildings, road_net,
                                             proposed_paths, save_path=infra_path)
    conn_fig     = render_connectivity_map(seg_mask, buildings, road_net,
                                           proposed_paths, save_path=conn_path)
    dash_fig     = render_dashboard(stats, buildings, conn_fig,
                                    save_path=dash_path)

    # ── STEP 4: PDF Report ────────────────────────────────
    logger.info("\n[Step 4/4] Exporting PDF report...")
    export_pdf_report(infra_fig, conn_fig, dash_fig, stats, pdf_path)

    logger.info("\n" + "=" * 60)
    logger.info("  PIPELINE COMPLETE")
    logger.info(f"  Outputs saved to: {os.path.abspath(output_dir)}")
    logger.info("=" * 60)

    # Close figures to free memory
    plt.close("all")

    return {
        "buildings":        buildings,
        "road_network":     road_net,
        "proposed_paths":   proposed_paths,
        "statistics":       stats,
        "files": {
            "infrastructure_map": infra_path,
            "connectivity_map":   conn_path,
            "dashboard":          dash_path,
            "pdf_report":         pdf_path,
            "buildings_csv":      b_csv,
            "statistics_csv":     s_csv,
        }
    }


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger.info("=== Module 3: Final Output Module ===")

    # ── Replace this with your actual DINOv2 segmentation mask ──────────────
    # Example: mask = np.load("your_segmentation_mask.npy")
    #      or: mask = cv2.imread("mask.png", cv2.IMREAD_GRAYSCALE)
    mask = generate_synthetic_mask(H=512, W=512)

    # Optional: manually assign priorities to specific buildings
    # priority_map = {1: "Hospital", 3: "School", 5: "Government Office"}
    priority_map = None

    results = run_full_pipeline(
        seg_mask=mask,
        output_dir="smart_village_output",
        priority_map=priority_map,
        connect_threshold=20,
        downsample=2
    )

    print("\n=== Output Files ===")
    for name, path in results["files"].items():
        print(f"  {name:25s}: {path}")

    print("\n=== Key Statistics ===")
    s = results["statistics"]
    print(f"  Total Buildings    : {s['total_buildings']}")
    print(f"  Connected          : {s['connected_buildings']}")
    print(f"  Unconnected        : {s['unconnected_buildings']}")
    print(f"  Connectivity %     : {s['connectivity_pct']}%")
    print(f"  Avg Dist to Road   : {s['avg_distance_to_road']} px")
    print(f"  Proposed Roads     : {s['proposed_roads_count']}")
