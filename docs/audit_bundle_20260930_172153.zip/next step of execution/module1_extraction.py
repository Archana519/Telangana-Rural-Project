"""
Module 1: Building & Road Extraction
=====================================
Smart Village Infrastructure Analysis Pipeline
M.Tech Project - DINOv2 Semantic Segmentation Post-Processing

Author: [Your Name]
Description:
    Extracts buildings and road networks from DINOv2/LoveDA segmentation masks.
    Outputs contours, centroids, and skeletonized road data.

Run standalone test:
    python module1_extraction.py
"""

import cv2
import numpy as np
from dataclasses import dataclass, field
from typing import List, Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ── Class Label Map (LoveDA) ─────────────────────────────────────────────────
CLASS_LABELS = {
    0: "Background", 1: "Building", 2: "Road",
    3: "Barren",     4: "Forest",   5: "Water", 6: "Agriculture",
}

# ── Data Classes ─────────────────────────────────────────────────────────────

@dataclass
class Building:
    id: int
    centroid: Tuple[int, int]
    contour: np.ndarray
    bounding_box: Tuple[int, int, int, int]
    area: float
    priority: str = "Residential"
    connected: bool = False
    nearest_road_point: Optional[Tuple[int, int]] = None
    distance_to_road: float = float("inf")
    accessibility_score: float = 0.0

@dataclass
class RoadNetwork:
    mask: np.ndarray
    skeleton: np.ndarray
    contours: List[np.ndarray]
    pixel_coords: List[Tuple[int, int]] = field(default_factory=list)


# ── Extraction Functions ──────────────────────────────────────────────────────

def extract_buildings(seg_mask: np.ndarray, min_area: int = 50) -> List[Building]:
    building_mask = np.uint8(seg_mask == 1) * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    building_mask = cv2.morphologyEx(building_mask, cv2.MORPH_CLOSE, kernel)
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
        building_mask, connectivity=8)
    buildings = []
    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < min_area:
            continue
        x = stats[i, cv2.CC_STAT_LEFT];  y = stats[i, cv2.CC_STAT_TOP]
        w = stats[i, cv2.CC_STAT_WIDTH]; h = stats[i, cv2.CC_STAT_HEIGHT]
        cx, cy = int(centroids[i][0]), int(centroids[i][1])
        component_mask = np.uint8(labels == i) * 255
        contours, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contour = contours[0] if contours else np.array([])
        buildings.append(Building(id=i, centroid=(cx, cy), contour=contour,
                                  bounding_box=(x, y, w, h), area=float(area)))
    logger.info(f"Extracted {len(buildings)} buildings (min_area={min_area}px)")
    return buildings


def extract_road_network(seg_mask: np.ndarray, skeletonize: bool = True) -> RoadNetwork:
    road_mask = np.uint8(seg_mask == 2) * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    road_mask = cv2.morphologyEx(road_mask, cv2.MORPH_CLOSE, kernel)
    contours, _ = cv2.findContours(road_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    skeleton = _skeletonize_mask(road_mask) if skeletonize else np.zeros_like(road_mask)
    pixel_coords = list(zip(*np.where(skeleton > 0)))
    logger.info(f"Road: {road_mask.sum()//255} px, skeleton: {len(pixel_coords)} px, {len(contours)} segments")
    return RoadNetwork(mask=road_mask, skeleton=skeleton, contours=contours, pixel_coords=pixel_coords)


def _skeletonize_mask(binary_mask: np.ndarray) -> np.ndarray:
    img = binary_mask.copy()
    skeleton = np.zeros_like(img)
    kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    for _ in range(500):
        eroded = cv2.erode(img, kernel)
        opened = cv2.dilate(eroded, kernel)
        temp = cv2.subtract(img, opened)
        skeleton = cv2.bitwise_or(skeleton, temp)
        img = eroded.copy()
        if cv2.countNonZero(img) == 0:
            break
    return skeleton


def visualize_extraction(seg_mask, buildings, road_network, save_path=None):
    color_map = {0:(50,50,50),1:(180,120,60),2:(200,200,200),
                 3:(210,180,140),4:(34,139,34),5:(65,105,225),6:(154,205,50)}
    H, W = seg_mask.shape
    vis = np.zeros((H, W, 3), dtype=np.uint8)
    for label, color in color_map.items():
        vis[seg_mask == label] = color[::-1]
    vis[road_network.skeleton > 0] = (0, 255, 255)
    for b in buildings:
        if b.contour.size > 0:
            cv2.drawContours(vis, [b.contour], -1, (0, 200, 255), 1)
        cv2.circle(vis, b.centroid, 3, (0, 165, 255), -1)
    if save_path:
        cv2.imwrite(save_path, vis)
    return vis


def generate_synthetic_mask(H: int = 512, W: int = 512) -> np.ndarray:
    mask = np.zeros((H, W), dtype=np.uint8)
    mask[:120, :] = 4; mask[400:, :] = 3
    mask[150:220, 350:480] = 5; mask[250:400, 300:512] = 6
    mask[200, :] = 2; mask[300, :] = 2
    mask[:, 100] = 2; mask[:, 250] = 2; mask[:, 400] = 2
    for (r, c, h, w) in [(130,130,25,20),(190,130,20,20),(130,220,22,18),
                          (190,220,20,20),(310,130,25,22),(370,130,20,18),
                          (310,220,20,20),(370,220,22,20),(130,320,18,15),
                          (430,320,20,18),(450,120,22,20),(460,220,20,20)]:
        mask[r:r+h, c:c+w] = 1
    return mask


# ── Standalone test ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    logger.info("=== Module 1: Extraction Test ===")

    img = cv2.imread(
        r"D:\remoteSensingWebApp\test_samples\4208.png",
        cv2.IMREAD_GRAYSCALE
    )

    print("Shape:", img.shape)
    print("Min:", img.min())
    print("Max:", img.max())
    print("Unique values:", np.unique(img)[:30])

    # Stop here for now
    exit()
    vis = visualize_extraction(mask, buildings, road_net, save_path="extraction_output.png")
    print(f"\n Buildings found : {len(buildings)}")
    print(f" Road pixels     : {len(road_net.pixel_coords)}")
    plt.figure(figsize=(8, 8))
    plt.imshow(cv2.cvtColor(vis, cv2.COLOR_BGR2RGB))
    plt.title("Module 1 - Building & Road Extraction")
    plt.axis("off"); plt.tight_layout(); plt.show()
