import sys
import cv2
import numpy as np

# Existing Module 1 location
sys.path.insert(
    0,
    r"D:\new_MPS\remoteSensingWebApp\next step of execution"
)

from module1_extraction import (
    extract_buildings,
    extract_road_network
)

from module2_connectivity import (
    build_road_graph,
    analyze_connectivity,
    assign_priorities,
    generate_proposed_roads,
    compute_statistics,
    visualize_connectivity
)


# ---------------------------------------------------------
# INPUT
# ---------------------------------------------------------

prediction_path = (
    r"D:\new_MPS\remoteSensingWebApp\project"
    r"\selected_tile_prediction.png"
)

output_path = "module2_3515_connectivity.png"


# ---------------------------------------------------------
# LOAD SEGMENTATION PREDICTION
# ---------------------------------------------------------

seg_mask = cv2.imread(
    prediction_path,
    cv2.IMREAD_GRAYSCALE
)

if seg_mask is None:
    raise FileNotFoundError(
        f"Prediction not found:\n{prediction_path}"
    )

print("Segmentation shape:", seg_mask.shape)
print("Segmentation classes:", np.unique(seg_mask))


# ---------------------------------------------------------
# MODULE 1: BUILDING + ROAD EXTRACTION
# ---------------------------------------------------------

buildings = extract_buildings(
    seg_mask,
    min_area=50
)

road_network = extract_road_network(
    seg_mask,
    skeletonize=True
)

print("\n========== MODULE 1 ==========")
print("Buildings:", len(buildings))
print("Road pixels:", int(np.sum(road_network.mask > 0)))
print("Skeleton pixels:", len(road_network.pixel_coords))


# ---------------------------------------------------------
# MODULE 2: ROAD GRAPH
# ---------------------------------------------------------

G, kdtree, nodes = build_road_graph(
    road_network,
    downsample=2
)

print("\n========== ROAD GRAPH ==========")
print("Graph nodes:", G.number_of_nodes())
print("Graph edges:", G.number_of_edges())


# ---------------------------------------------------------
# CONNECTIVITY ANALYSIS
# ---------------------------------------------------------

buildings = analyze_connectivity(
    buildings,
    G,
    kdtree,
    nodes,
    connect_threshold=20
)

print("\n========== CONNECTIVITY ==========")

for b in buildings:
    print(
        f"Building {b.id}: "
        f"area={b.area:.0f}px, "
        f"centroid={b.centroid}, "
        f"distance={b.distance_to_road:.2f}px, "
        f"connected={b.connected}"
    )


# ---------------------------------------------------------
# PRIORITY ASSIGNMENT
# ---------------------------------------------------------

buildings = assign_priorities(buildings)

print("\n========== PRIORITIES ==========")

for b in buildings:
    print(
        f"Building {b.id}: "
        f"{b.priority}"
    )


# ---------------------------------------------------------
# PROPOSED ROADS
# ---------------------------------------------------------

proposed_paths = generate_proposed_roads(
    buildings,
    G,
    kdtree,
    nodes,
    seg_mask.shape
)

print("\n========== PROPOSED ROADS ==========")
print(
    "Proposed road paths:",
    len(proposed_paths)
)


# ---------------------------------------------------------
# STATISTICS
# ---------------------------------------------------------

stats = compute_statistics(
    buildings,
    road_network,
    proposed_paths
)

print("\n========== FINAL STATISTICS ==========")

for key, value in stats.items():
    print(f"{key}: {value}")


# ---------------------------------------------------------
# VISUALIZATION
# ---------------------------------------------------------

visualize_connectivity(
    seg_mask,
    buildings,
    road_network,
    proposed_paths,
    save_path=output_path
)

print("\nVisualization saved to:")
print(output_path)