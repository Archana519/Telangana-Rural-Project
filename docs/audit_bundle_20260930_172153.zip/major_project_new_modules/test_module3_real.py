import sys
import os
import cv2
import numpy as np

# ============================================================
# ADD THE FOLDER CONTAINING MODULE 1, MODULE 2, MODULE 3
# ============================================================

NEXT_STEP_DIR = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\next step of execution"
)

if NEXT_STEP_DIR not in sys.path:
    sys.path.insert(0, NEXT_STEP_DIR)

# ============================================================
# NOW IMPORT MODULE 3
# ============================================================

from module3_final_output import run_full_pipeline


# ============================================================
# REAL STRONGDINOV2SEG PREDICTION
# ============================================================

prediction_path = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\project\selected_tile_prediction.png"
)

# ============================================================
# OUTPUT DIRECTORY
# ============================================================

output_dir = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\project\real_3515_output"
)


# ============================================================
# CHECK INPUT
# ============================================================

if not os.path.exists(prediction_path):
    raise FileNotFoundError(
        "Segmentation prediction not found:\n"
        + prediction_path
    )


# ============================================================
# LOAD SEGMENTATION MASK
# ============================================================

mask = cv2.imread(
    prediction_path,
    cv2.IMREAD_GRAYSCALE
)

if mask is None:
    raise RuntimeError(
        "Could not read segmentation prediction:\n"
        + prediction_path
    )


# ============================================================
# INPUT INFORMATION
# ============================================================

print()
print("=" * 60)
print("REAL TILE 3515 - MODULE 3 TEST")
print("=" * 60)

print("Prediction:")
print(prediction_path)

print()
print("Mask shape:")
print(mask.shape)

print()
print("Predicted classes:")
print(np.unique(mask))


# ============================================================
# RUN COMPLETE MODULE 3 PIPELINE
# ============================================================

results = run_full_pipeline(
    seg_mask=mask,
    output_dir=output_dir,
    priority_map=None,
    connect_threshold=20,
    downsample=2
)


# ============================================================
# PRINT STATISTICS
# ============================================================

print()
print("=" * 60)
print("KEY STATISTICS")
print("=" * 60)

stats = results["statistics"]

for key, value in stats.items():
    print(f"{key}: {value}")


# ============================================================
# PRINT OUTPUT FILES
# ============================================================

print()
print("=" * 60)
print("OUTPUT FILES")
print("=" * 60)

for name, path in results["files"].items():
    print(f"{name}: {path}")


# ============================================================
# FINISHED
# ============================================================

print()
print("=" * 60)
print("MODULE 3 REAL-TILE TEST COMPLETED")
print("=" * 60)