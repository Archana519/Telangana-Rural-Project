# New Modules — Layers 3-6 (GIS / Accessibility / Routing / Evaluation)

Starter implementations for the parts of the architecture that don't exist
yet, matching the repo layout from the 2-month plan. Each file is a
starting point, not a finished pipeline — every function documents what
input shape it expects from the stage before it, since these plug into your
existing mini-project's building/road extraction (OpenCV connected
components + skeletonization), which isn't reproduced here.

## Read this first
`03_georeferencing/georeference.py` documents an important constraint:
**LoveDA tiles have no real-world coordinates in the public release.**
Route lengths can still be converted to real meters (Track A — use this for
everything), but true OpenStreetMap facility tagging needs real coordinates
and is only possible for tiles you manually geolocate by eye against Google
Earth (Track B — optional, 1-3 tiles at most). `04_facility_tagging/`
mirrors this with a heuristic proxy tagger (Track A, use everywhere) and a
real Overpass API query (Track B, stretch goal).

## Pipeline order

1. **`03_georeferencing/georeference.py`** — convert your existing
   pixel-space road graph's edge weights to meters (`metric_graph_from_pixel_graph`).
2. **`04_facility_tagging/facility_tagging.py`** — tag each building
   `"P1_candidate"` or `"P2"` using the heuristic (`tag_all_buildings_heuristic`),
   fed by your existing building-detection stats (OpenCV
   `connectedComponentsWithStats` output: area + centroid per building).
3. **`05_accessibility_priority/accessibility.py`** — rank every building by
   `gap_score` (`accessibility_gap_scores`), using your existing road
   skeleton pixels (scikit-image `skeletonize()` output).
4. **`06_routing_optimization/multi_route.py`** — for each priority gap,
   generate k candidate routes (`generate_candidate_routes`, with
   `perturbed_astar_routes` as a fallback), score them
   (`score_route` + `normalize_metric`), then merge shared segments
   (`find_shared_segments` + `shared_road_benefit`).
5. **`07_evaluation/gis_experiments.py`** — run the two GIS-side baselines
   (`run_nearest_road_baseline`, `run_shortest_astar_baseline`) plus your
   proposed method's summary (`run_proposed_method`) per tile, save each as
   JSON, then write your own `aggregate_gis_results.py` that calls
   `load_all_results()` and builds tables — mirroring
   `02_segmentation/aggregate_results.py` exactly, just with GIS metrics
   instead of segmentation metrics.

## Dependencies to install

```bash
pip install networkx scipy numpy requests
```
(`osmnx`/`pyproj` are only needed if you pursue Track B georeferencing —
skip them otherwise, they add setup overhead you don't need for Track A.)

## What's NOT included here

Your actual building-detection and road-skeleton-extraction code (the
OpenCV/NetworkX/A* pipeline described in your mini-project paper, Sections
4.1-4.2) isn't reproduced in these files — they assume it already exists
and plug in after it. If that code isn't already factored into reusable
functions, that's worth doing first so these new modules can call it
directly instead of copy-pasting pixel-processing logic.
