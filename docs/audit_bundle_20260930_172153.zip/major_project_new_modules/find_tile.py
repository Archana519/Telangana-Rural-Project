import sys
import cv2
import torch
import numpy as np
import os

sys.path.insert(0, r"D:\new_MPS\remoteSensingWebApp\project")

from model import StrongDINOv2Seg

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

CHECKPOINT = r"D:\new_MPS\remoteSensingWebApp\checkpoints\best_model.pth"

IMAGE_DIR = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\LoveDA Satellite Images Semantic Segmentation"
    r"\Val\Val\Urban\images_png"
)

print("Device:", DEVICE)
print("Loading model...")

model = StrongDINOv2Seg().to(DEVICE)

checkpoint = torch.load(
    CHECKPOINT,
    map_location=DEVICE,
    weights_only=False
)

model.load_state_dict(
    checkpoint["state_dict"],
    strict=False
)

model.eval()

print("Model loaded successfully.")
print("Searching for a tile containing Building + Road...\n")

files = sorted(
    f for f in os.listdir(IMAGE_DIR)
    if f.lower().endswith(".png")
)

for index, filename in enumerate(files, start=1):

    path = os.path.join(IMAGE_DIR, filename)

    image = cv2.imread(path)

    if image is None:
        continue

    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    resized = cv2.resize(
        image,
        (560, 560)
    )

    tensor = (
        torch.tensor(
            resized.astype(np.float32) / 255.0
        )
        .permute(2, 0, 1)
        .unsqueeze(0)
        .to(DEVICE)
    )

    with torch.no_grad():
        logits = model(tensor)

    pred = torch.argmax(
        logits,
        dim=1
    ).squeeze().cpu().numpy()

    classes = np.unique(pred)

    print(
        f"{index}/{len(files)} - {filename} - classes: {classes}"
    )

    if 1 in classes and 2 in classes:

        building_pixels = int((pred == 1).sum())
        road_pixels = int((pred == 2).sum())

        print("\n========================================")
        print("FOUND SUITABLE TILE")
        print("Image:", filename)
        print("Building pixels:", building_pixels)
        print("Road pixels:", road_pixels)
        print("Classes:", classes)
        print("========================================")

        output = (
            r"D:\new_MPS\remoteSensingWebApp\project"
            r"\selected_tile_prediction.png"
        )

        cv2.imwrite(
            output,
            pred.astype(np.uint8)
        )

        print("Prediction saved to:")
        print(output)

        break

else:
    print("\nNo suitable tile was found.")