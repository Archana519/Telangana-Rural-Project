import sys
import cv2
import numpy as np

# ============================================================
# PATHS
# ============================================================

NEXT_STEP_DIR = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\next step of execution"
)

LAYER4_DIR = (
    r"C:\Users\DELL\Downloads\new_modules_layers3-6"
    r"\major_project_new_modules"
    r"\04_facility_tagging"
)

if NEXT_STEP_DIR not in sys.path:
    sys.path.insert(0, NEXT_STEP_DIR)

if LAYER4_DIR not in sys.path:
    sys.path.insert(0, LAYER4_DIR)


# ============================================================
# IMPORTS
# ============================================================

from module1_extraction import extract_buildings
from facility_tagging import (
    heuristic_priority_tag,
    tag_all_buildings_heuristic,
    LARGE_BUILDING_PX_AREA,
    CLUSTER_RADIUS_PX,
)


# ============================================================
# INPUT
# ============================================================

prediction_path = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\project\selected_tile_prediction.png"
)


# ============================================================
# LOAD SEGMENTATION PREDICTION
# ============================================================

seg_mask = cv2.imread(
    prediction_path,
    cv2.IMREAD_GRAYSCALE
)

if seg_mask is None:
    raise FileNotFoundError(
        f"Prediction not found:\n{prediction_path}"
    )


print("=" * 60)
print("LAYER 4 - FACILITY TAGGING")
print("REAL TILE 3515")
print("=" * 60)

print("Mask shape:", seg_mask.shape)
print("Classes:", np.unique(seg_mask))

print()
print("Heuristic threshold:")
print(
    "Large building area >",
    LARGE_BUILDING_PX_AREA,
    "px"
)

print(
    "Cluster radius:",
    CLUSTER_RADIUS_PX,
    "px"
)


# ============================================================
# MODULE 1: EXTRACT BUILDINGS
# ============================================================

buildings = extract_buildings(
    seg_mask,
    min_area=50
)

print()
print("Buildings extracted:", len(buildings))


# ============================================================
# CONVERT BUILDINGS TO LAYER 4 INPUT FORMAT
# ============================================================

building_stats = []

for b in buildings:

    building_stats.append(
        {
            "id": b.id,
            "area": b.area,
            "centroid": b.centroid,
        }
    )


# ============================================================
# APPLY LAYER 4 HEURISTIC
# ============================================================

tagged_buildings = tag_all_buildings_heuristic(
    building_stats
)


# ============================================================
# DISPLAY RESULTS
# ============================================================

print()
print("=" * 60)
print("FACILITY PRIORITY TAGS")
print("=" * 60)

p1_count = 0
p2_count = 0

for b in tagged_buildings:

    if b["priority"] == "P1_candidate":
        p1_count += 1
    else:
        p2_count += 1

    print(
        f"Building {b['id']:2d} | "
        f"Area: {b['area']:10.2f} px | "
        f"Centroid: {b['centroid']} | "
        f"Priority: {b['priority']}"
    )


# ============================================================
# SUMMARY
# ============================================================

print()
print("=" * 60)
print("LAYER 4 SUMMARY")
print("=" * 60)

print("Total buildings :", len(tagged_buildings))
print("P1 candidates   :", p1_count)
print("P2 buildings    :", p2_count)

print()
print(
    "P1_candidate means a geometry-based "
    "public-service-like candidate."
)

print(
    "It does NOT confirm that the building "
    "is a hospital, school, or government facility."
)

print()
print("Layer 4 completed successfully.")