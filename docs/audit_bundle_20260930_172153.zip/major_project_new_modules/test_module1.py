import sys
import cv2
import numpy as np

sys.path.insert(
    0,
    r"D:\new_MPS\remoteSensingWebApp\next step of execution"
)

from module1_extraction import (
    extract_buildings,
    extract_road_network,
    visualize_extraction
)

prediction_path = (
    r"D:\new_MPS\remoteSensingWebApp\project"
    r"\selected_tile_prediction.png"
)

output_path = "module1_3515_extraction.png"

seg_mask = cv2.imread(
    prediction_path,
    cv2.IMREAD_GRAYSCALE
)

if seg_mask is None:
    raise FileNotFoundError(
        f"Prediction not found: {prediction_path}"
    )

print("Prediction shape:", seg_mask.shape)
print("Prediction classes:", np.unique(seg_mask))

buildings = extract_buildings(
    seg_mask,
    min_area=50
)

road_network = extract_road_network(
    seg_mask,
    skeletonize=True
)

print("\n========== MODULE 1 RESULT ==========")
print("Buildings found :", len(buildings))
print("Road pixels     :", int(np.sum(road_network.mask > 0)))
print("Skeleton pixels :", len(road_network.pixel_coords))
print("Road segments   :", len(road_network.contours))

vis = visualize_extraction(
    seg_mask,
    buildings,
    road_network,
    save_path=output_path
)

print("\nVisualization saved to:")
print(output_path)