"""
Layer 3 - Georeferencing.

IMPORTANT (read this before using this module):
LoveDA tiles, as publicly released, do NOT ship per-image lat/lon or an
affine geotransform. The dataset only documents that source imagery came
from Nanjing / Changzhou / Wuhan in general -- there is no per-tile GPS
metadata file. This means "convert to real georeferenced coordinates" cannot
mean true map coordinates for every tile out of the box.

Two tracks are implemented here:

TRACK A (default -- use for every tile, every experiment):
    Approximate METRIC conversion using the known ground sampling distance
    (GSD), not real coordinates. LoveDA's native GSD is ~0.3 m/px at
    1024x1024; after resizing to 560x560 (as in your mini-project) the
    effective GSD is ~0.55 m/px. This gives real-world *distances* in
    meters for route lengths / accessibility gaps, which is what your
    scoring function (Layer 5) actually needs. It does NOT give you a real
    map location, so you cannot query OpenStreetMap around it.

TRACK B (optional, stretch goal, at most 1-3 tiles):
    Manually geolocate a handful of tiles by eye-matching them against
    Google Earth/Maps imagery of the three source cities, then hand-record
    an approximate top-left lat/lon + tile rotation. Slow, approximate, and
    should only be used to *demonstrate* that the OSM-tagging pipeline in
    04_facility_tagging/ works end-to-end -- not for a generalization claim.
"""
from dataclasses import dataclass

EFFECTIVE_GSD_M_PER_PX = 0.55  # matches the mini-project paper, Section 4.2


def pixel_length_to_meters(pixel_length: float) -> float:
    """Track A. Convert a pixel-space path length (e.g. an A* route length
    in pixels) to meters. No coordinate lookup needed -- use this for every
    tile, every route, every experiment."""
    return pixel_length * EFFECTIVE_GSD_M_PER_PX


def metric_graph_from_pixel_graph(G):
    """Track A. Re-weight an existing NetworkX road graph (built in pixel
    space, edges weighted 1.0 / sqrt(2) as in your mini-project's road
    skeleton graph) so edge weights are in meters. Node positions stay in
    pixel space since there is no real coordinate system to place them in
    under Track A."""
    G2 = G.copy()
    for _, _, data in G2.edges(data=True):
        data["weight_m"] = data.get("weight", 1.0) * EFFECTIVE_GSD_M_PER_PX
    return G2


@dataclass
class ManualTileGeoreference:
    """Track B. Fill this in by hand for a tile you've visually matched on
    Google Earth. top_left_lat/lon is the geographic coordinate of pixel
    (0, 0); rotation_deg is clockwise rotation of the tile relative to
    north (usually 0 for LoveDA tiles, but check).
    """
    tile_id: str
    top_left_lat: float
    top_left_lon: float
    rotation_deg: float = 0.0
    gsd_m_per_px: float = EFFECTIVE_GSD_M_PER_PX

    def pixel_to_latlon(self, px: float, py: float):
        """Approximate flat-earth conversion -- fine at this scale (a few
        hundred meters across a tile), not accurate over long distances."""
        import math
        dx_m = px * self.gsd_m_per_px
        dy_m = py * self.gsd_m_per_px
        theta = math.radians(self.rotation_deg)
        east_m = dx_m * math.cos(theta) + dy_m * math.sin(theta)
        north_m = -dx_m * math.sin(theta) + dy_m * math.cos(theta)
        meters_per_deg_lat = 111_320.0
        meters_per_deg_lon = 111_320.0 * math.cos(math.radians(self.top_left_lat))
        lat = self.top_left_lat - (north_m / meters_per_deg_lat)
        lon = self.top_left_lon + (east_m / meters_per_deg_lon)
        return lat, lon

    def tile_bbox_latlon(self, tile_width_px: int, tile_height_px: int):
        """Returns (south, west, north, east) for use with
        04_facility_tagging.osm_facility_tags_for_bbox()."""
        lat_tl, lon_tl = self.pixel_to_latlon(0, 0)
        lat_br, lon_br = self.pixel_to_latlon(tile_width_px, tile_height_px)
        south, north = sorted([lat_tl, lat_br])
        west, east = sorted([lon_tl, lon_br])
        return south, west, north, east


# Example manual entries -- replace with your own after visually matching
# a tile against Google Earth. Leave empty until you've actually done this.
MANUAL_GEOREFS = {
    # "4216": ManualTileGeoreference("4216", top_left_lat=32.05, top_left_lon=118.78),
}
