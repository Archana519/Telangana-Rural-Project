import sys
import cv2
import numpy as np

# ---------------------------------------------------------
# Existing modules
# ---------------------------------------------------------

NEXT_STEP_DIR = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\next step of execution"
)

if NEXT_STEP_DIR not in sys.path:
    sys.path.insert(0, NEXT_STEP_DIR)

# ---------------------------------------------------------
# Layer 3
# ---------------------------------------------------------

LAYER3_DIR = (
    r"C:\Users\DELL\Downloads\new_modules_layers3-6"
    r"\major_project_new_modules\03_georeferencing"
)

if LAYER3_DIR not in sys.path:
    sys.path.insert(0, LAYER3_DIR)

from module1_extraction import (
    extract_buildings,
    extract_road_network,
)

from module2_connectivity import (
    build_road_graph,
    analyze_connectivity,
)

from georeference import (
    EFFECTIVE_GSD_M_PER_PX,
    pixel_length_to_meters,
    metric_graph_from_pixel_graph,
)


# ---------------------------------------------------------
# Input
# ---------------------------------------------------------

prediction_path = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\project\selected_tile_prediction.png"
)

# ---------------------------------------------------------
# Load prediction
# ---------------------------------------------------------

seg_mask = cv2.imread(
    prediction_path,
    cv2.IMREAD_GRAYSCALE
)

if seg_mask is None:
    raise FileNotFoundError(
        f"Prediction not found:\n{prediction_path}"
    )


print("=" * 60)
print("LAYER 3 - REAL TILE 3515 TEST")
print("=" * 60)

print("Mask shape:", seg_mask.shape)
print("Classes:", np.unique(seg_mask))

print()
print("Effective GSD:", EFFECTIVE_GSD_M_PER_PX, "m/pixel")


# ---------------------------------------------------------
# Module 1
# ---------------------------------------------------------

buildings = extract_buildings(
    seg_mask,
    min_area=50
)

road_network = extract_road_network(
    seg_mask,
    skeletonize=True
)


# ---------------------------------------------------------
# Module 2 graph
# ---------------------------------------------------------

G, kdtree, nodes = build_road_graph(
    road_network,
    downsample=2
)

buildings = analyze_connectivity(
    buildings,
    G,
    kdtree,
    nodes,
    connect_threshold=20
)


# ---------------------------------------------------------
# Pixel -> meter conversion
# ---------------------------------------------------------

print()
print("=" * 60)
print("BUILDING ACCESSIBILITY DISTANCES")
print("=" * 60)

for b in buildings:

    distance_px = b.distance_to_road

    distance_m = pixel_length_to_meters(
        distance_px
    )

    print(
        f"Building {b.id:2d} | "
        f"Distance: {distance_px:8.2f} px | "
        f"{distance_m:8.2f} m | "
        f"Connected: {b.connected}"
    )


# ---------------------------------------------------------
# Metric graph
# ---------------------------------------------------------

metric_graph = metric_graph_from_pixel_graph(
    G
)

print()
print("=" * 60)
print("ROAD GRAPH")
print("=" * 60)

print(
    "Pixel graph nodes:",
    G.number_of_nodes()
)

print(
    "Pixel graph edges:",
    G.number_of_edges()
)

print(
    "Metric graph nodes:",
    metric_graph.number_of_nodes()
)

print(
    "Metric graph edges:",
    metric_graph.number_of_edges()
)


# ---------------------------------------------------------
# Example edge conversion
# ---------------------------------------------------------

if G.number_of_edges() > 0:

    u, v, data = next(
        iter(G.edges(data=True))
    )

    pixel_weight = data.get(
        "weight",
        0.0
    )

    meter_weight = metric_graph[u][v].get(
        "weight_m",
        0.0
    )

    print()
    print("=" * 60)
    print("SAMPLE EDGE CONVERSION")
    print("=" * 60)

    print("Edge:", u, "->", v)
    print(
        "Pixel distance:",
        round(pixel_weight, 4),
        "px"
    )

    print(
        "Metric distance:",
        round(meter_weight, 4),
        "m"
    )


# ---------------------------------------------------------
# Connectivity threshold conversion
# ---------------------------------------------------------

threshold_px = 20

threshold_m = pixel_length_to_meters(
    threshold_px
)

print()
print("=" * 60)
print("CONNECTIVITY THRESHOLD")
print("=" * 60)

print(
    "Threshold:",
    threshold_px,
    "px"
)

print(
    "Equivalent:",
    round(threshold_m, 2),
    "m"
)


# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------

connected = sum(
    1 for b in buildings
    if b.connected
)

unconnected = len(buildings) - connected

print()
print("=" * 60)
print("LAYER 3 SUMMARY")
print("=" * 60)

print(
    "Buildings:",
    len(buildings)
)

print(
    "Connected:",
    connected
)

print(
    "Unconnected:",
    unconnected
)

print(
    "GSD:",
    EFFECTIVE_GSD_M_PER_PX,
    "m/pixel"
)

print()
print(
    "Layer 3 metric conversion completed successfully."
)