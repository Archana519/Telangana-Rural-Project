import sys
import cv2
import numpy as np

# ============================================================
# PATHS
# ============================================================

NEXT_STEP_DIR = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\next step of execution"
)

LAYER4_DIR = (
    r"C:\Users\DELL\Downloads\new_modules_layers3-6"
    r"\major_project_new_modules"
    r"\04_facility_tagging"
)

LAYER5_DIR = (
    r"C:\Users\DELL\Downloads\new_modules_layers3-6"
    r"\major_project_new_modules"
    r"\05_accessibility_priority"
)

if NEXT_STEP_DIR not in sys.path:
    sys.path.insert(0, NEXT_STEP_DIR)

if LAYER4_DIR not in sys.path:
    sys.path.insert(0, LAYER4_DIR)

if LAYER5_DIR not in sys.path:
    sys.path.insert(0, LAYER5_DIR)


# ============================================================
# IMPORTS
# ============================================================

from module1_extraction import (
    extract_buildings,
    extract_road_network,
)

from facility_tagging import (
    tag_all_buildings_heuristic,
)

from accessibility import (
    accessibility_gap_scores,
    priority_summary,
)


# ============================================================
# INPUT
# ============================================================

prediction_path = (
    r"D:\new_MPS\remoteSensingWebApp"
    r"\project\selected_tile_prediction.png"
)


# ============================================================
# LOAD PREDICTION
# ============================================================

seg_mask = cv2.imread(
    prediction_path,
    cv2.IMREAD_GRAYSCALE
)

if seg_mask is None:
    raise FileNotFoundError(
        f"Prediction not found:\n{prediction_path}"
    )


print("=" * 60)
print("LAYER 5 - ACCESSIBILITY PRIORITY")
print("REAL TILE 3515")
print("=" * 60)

print("Mask shape:", seg_mask.shape)
print("Classes:", np.unique(seg_mask))


# ============================================================
# MODULE 1: BUILDINGS + ROAD
# ============================================================

buildings = extract_buildings(
    seg_mask,
    min_area=50
)

road_network = extract_road_network(
    seg_mask,
    skeletonize=True
)

print()
print("Buildings:", len(buildings))
print(
    "Road skeleton pixels:",
    len(road_network.pixel_coords)
)


# ============================================================
# CONVERT BUILDINGS TO LAYER 4 FORMAT
# ============================================================

building_stats = []

for b in buildings:

    building_stats.append(
        {
            "id": b.id,
            "area": b.area,
            "centroid": b.centroid,
        }
    )


# ============================================================
# LAYER 4: PRIORITY TAGGING
# ============================================================

building_stats = tag_all_buildings_heuristic(
    building_stats
)


# ============================================================
# LAYER 5: ACCESSIBILITY GAP
# ============================================================

ranked = accessibility_gap_scores(
    building_stats,
    road_network.pixel_coords
)


# ============================================================
# DISPLAY RESULTS
# ============================================================

print()
print("=" * 60)
print("ACCESSIBILITY GAP RANKING")
print("=" * 60)

for rank, b in enumerate(ranked, start=1):

    print(
        f"Rank {rank:2d} | "
        f"Building {b['id']:2d} | "
        f"Priority: {b['priority']:13s} | "
        f"Road distance: "
        f"{b['nearest_road_dist_px']:8.2f} px | "
        f"Gap score: "
        f"{b['gap_score']:8.2f}"
    )


# ============================================================
# CONVERT DISTANCES TO METERS
# ============================================================

GSD = 0.55

print()
print("=" * 60)
print("ACCESSIBILITY DISTANCES IN METERS")
print("=" * 60)

for rank, b in enumerate(ranked, start=1):

    distance_px = b["nearest_road_dist_px"]

    distance_m = distance_px * GSD

    print(
        f"Rank {rank:2d} | "
        f"Building {b['id']:2d} | "
        f"{distance_px:8.2f} px | "
        f"{distance_m:8.2f} m | "
        f"{b['priority']}"
    )


# ============================================================
# PRIORITY SUMMARY
# ============================================================

summary = priority_summary(
    ranked
)

print()
print("=" * 60)
print("PRIORITY SUMMARY")
print("=" * 60)

for key, value in summary.items():
    print(
        f"{key}: {value}"
    )


# ============================================================
# TOP PRIORITY GAPS
# ============================================================

print()
print("=" * 60)
print("TOP 5 ACCESSIBILITY GAPS")
print("=" * 60)

for rank, b in enumerate(
    ranked[:5],
    start=1
):

    distance_m = (
        b["nearest_road_dist_px"] * GSD
    )

    print(
        f"{rank}. Building {b['id']} | "
        f"Priority={b['priority']} | "
        f"Distance={distance_m:.2f} m | "
        f"Gap={b['gap_score']:.2f}"
    )


# ============================================================
# COMPLETION
# ============================================================

print()
print("=" * 60)
print("LAYER 5 COMPLETED SUCCESSFULLY")
print("=" * 60)