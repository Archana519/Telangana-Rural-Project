"""
Layer 4 - Accessibility gap analysis + priority assignment.

Reuses the KD-tree pattern already in your mini-project's connectivity
stage (scipy.spatial.cKDTree over road skeleton pixels), extended with the
priority tags from 04_facility_tagging/.
"""
from scipy.spatial import cKDTree


def accessibility_gap_scores(building_stats, road_skeleton_pixels):
    """
    building_stats: list of dicts, each with 'centroid': (x, y) and
        'priority': "P1_candidate" / "P2" (added by facility_tagging.py)
    road_skeleton_pixels: Nx2 array-like of (x, y) skeleton pixel coords
        (exactly what scikit-image's skeletonize() + np.argwhere gives you
        in your mini-project's road-extraction stage)

    Returns building_stats with two new keys added to each dict:
        'nearest_road_dist_px': float
        'gap_score': float (higher = more urgent to connect)
    Sorted descending by gap_score, so index 0 is the most urgent gap.
    """
    tree = cKDTree(road_skeleton_pixels) if len(road_skeleton_pixels) else None

    for b in building_stats:
        if tree is not None:
            dist, _ = tree.query(b["centroid"])
        else:
            dist = float("inf")
        priority_weight = 2.0 if b["priority"] == "P1_candidate" else 1.0
        b["nearest_road_dist_px"] = float(dist)
        b["gap_score"] = float(dist) * priority_weight

    return sorted(building_stats, key=lambda b: -b["gap_score"])


def priority_summary(building_stats):
    """Quick counts for a status update / slide: how many P1 vs P2 buildings,
    and how many of each are already road-connected vs isolated."""
    summary = {"P1_candidate": {"total": 0, "isolated": 0},
               "P2": {"total": 0, "isolated": 0}}
    for b in building_stats:
        tag = b["priority"]
        summary[tag]["total"] += 1
        if b.get("nearest_road_dist_px", 0) > 0:  # adjust threshold to your connectivity radius r
            summary[tag]["isolated"] += 1
    return summary
