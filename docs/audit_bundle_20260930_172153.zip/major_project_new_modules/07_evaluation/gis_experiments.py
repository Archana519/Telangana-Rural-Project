"""
Layer 6 - Evaluation: baselines, ablations, generalization.

Mirrors the pattern already used in 02_segmentation/aggregate_results.py
(read every experiment's saved JSON, build comparison tables) but for the
GIS/planning side instead of the segmentation side. Run one of these per
tile per experiment configuration, save a JSON, then aggregate.
"""
import json
import os

RESULTS_DIR = "results_gis"
os.makedirs(RESULTS_DIR, exist_ok=True)


def run_nearest_road_baseline(building_stats, road_skeleton_pixels):
    """Baseline 1: building -> nearest existing road pixel. No A*, no
    priority, no scoring -- just distance."""
    from scipy.spatial import cKDTree
    tree = cKDTree(road_skeleton_pixels) if len(road_skeleton_pixels) else None
    total_length = 0.0
    for b in building_stats:
        if tree is not None:
            dist, _ = tree.query(b["centroid"])
            total_length += dist
    return dict(method="nearest_road", total_length_px=total_length,
                num_connections=len(building_stats))


def run_shortest_astar_baseline(G, isolated_buildings, road_nodes, cost_weight="cost"):
    """Baseline 2: shortest-A* per isolated building, no priority, single
    route only -- this is approximately your mini-project's original
    method, now just re-run as an explicit comparison point."""
    import networkx as nx
    total_length, num_ok = 0.0, 0
    for b in isolated_buildings:
        best = None
        for target in road_nodes:
            try:
                length = nx.astar_path_length(G, b["node"], target, weight=cost_weight)
                if best is None or length < best:
                    best = length
            except (nx.NetworkXNoPath, nx.NodeNotFound):
                continue
        if best is not None:
            total_length += best
            num_ok += 1
    return dict(method="shortest_astar", total_length=total_length,
                num_connections=num_ok)


def run_proposed_method(scored_routes, shared_road_benefit_dict):
    """Baseline 3: your proposed method's summary -- priority-aware,
    multi-route, multi-criteria-scored, shared-road-optimized."""
    return dict(
        method="proposed",
        num_routes_considered=len(scored_routes),
        best_scores=[r["score"] for r in scored_routes],
        **shared_road_benefit_dict,
    )


def save_experiment_result(tile_id: str, experiment_name: str, result: dict):
    path = os.path.join(RESULTS_DIR, f"{tile_id}__{experiment_name}.json")
    with open(path, "w") as f:
        json.dump(result, f, indent=2)
    return path


def load_all_results():
    """Reads every saved result JSON in RESULTS_DIR -- call this from an
    aggregate_gis_results.py script (mirroring
    02_segmentation/aggregate_results.py) to build the baseline comparison,
    ablation, and generalization tables."""
    results = []
    for fname in sorted(os.listdir(RESULTS_DIR)):
        if fname.endswith(".json"):
            with open(os.path.join(RESULTS_DIR, fname)) as f:
                data = json.load(f)
            tile_id, experiment_name = fname[:-5].split("__", 1)
            data["_tile_id"] = tile_id
            data["_experiment_name"] = experiment_name
            results.append(data)
    return results
