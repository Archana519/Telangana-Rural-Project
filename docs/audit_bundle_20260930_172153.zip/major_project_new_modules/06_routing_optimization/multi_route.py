"""
Layer 5 - Multi-route generation + multi-criteria scoring + shared-road
optimization.

Builds on the same NetworkX graph and cost-weighted A* idea from your
mini-project (Section 4.2 of the paper): cost(p) = inf for water/no-data,
1 for road, 2 for agriculture, 3 for background, 4 for barren, 5 for
building, 8 for forest. That cost function is assumed to already be baked
into the graph's edge weights (attribute "cost") when you build G.
"""
import itertools
import networkx as nx
import numpy as np


def generate_candidate_routes(G, source, target, k=3, weight="cost"):
    """Preferred method: NetworkX's true k-shortest-paths. If your graph is
    too large for this to run in reasonable time on your tile sizes, fall
    back to perturbed_astar_routes() below."""
    try:
        gen = nx.shortest_simple_paths(G, source, target, weight=weight)
        return list(itertools.islice(gen, k))
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return []


def perturbed_astar_routes(G, source, target, k=3, base_weight="cost", jitter=0.15, seed=0):
    """Fallback: run A* several times, each with edge costs randomly
    perturbed by +/-jitter (default 15%), then de-duplicate identical
    paths. Use this if generate_candidate_routes() is too slow on your
    graph sizes."""
    rng = np.random.default_rng(seed)
    routes, seen = [], set()
    for _ in range(k * 3):  # try a few extra attempts; some will duplicate
        H = G.copy()
        for _, _, data in H.edges(data=True):
            factor = 1.0 + rng.uniform(-jitter, jitter)
            data["cost_jittered"] = data.get(base_weight, 1.0) * factor
        try:
            path = nx.astar_path(H, source, target, weight="cost_jittered")
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            continue
        key = tuple(path)
        if key not in seen:
            seen.add(key)
            routes.append(path)
        if len(routes) >= k:
            break
    return routes


# ---- Multi-criteria scoring (matches the paper's scoring formula) --------
EQUAL_WEIGHTS = dict(w1=1 / 6, w2=1 / 6, w3=1 / 6, w4=1 / 6, w5=1 / 6, w6=1 / 6)

# A couple of alternative weightings for the "2-3 alternative configurations"
# sensitivity check scoped for the 2-month plan -- adjust freely.
ACCESS_FOCUSED_WEIGHTS = dict(w1=0.35, w2=0.20, w3=0.20, w4=0.10, w5=0.10, w6=0.05)
COST_FOCUSED_WEIGHTS = dict(w1=0.15, w2=0.15, w3=0.15, w4=0.15, w5=0.15, w6=0.25)


def score_route(route_metrics: dict, weights: dict) -> float:
    """
    route_metrics keys: accessibility_gain, connectivity_gain,
        priority_benefit, land_suitability, length, cost
        (length/cost should be normalized 0-1 across candidates before
        scoring, same as the other four, so no single unit dominates)
    weights keys: w1..w6, matching Score(r) = w1*A + w2*C + w3*P + w4*S
        - w5*L - w6*Cost from the plan.
    """
    m = route_metrics
    return (weights["w1"] * m["accessibility_gain"]
            + weights["w2"] * m["connectivity_gain"]
            + weights["w3"] * m["priority_benefit"]
            + weights["w4"] * m["land_suitability"]
            - weights["w5"] * m["length"]
            - weights["w6"] * m["cost"])


def normalize_metric(values):
    """Min-max normalize a list of raw metric values to [0, 1] across a set
    of candidate routes, so length/cost don't dominate the score purely by
    being on a bigger numeric scale than the gain metrics."""
    values = np.asarray(values, dtype=float)
    lo, hi = values.min(), values.max()
    if hi - lo < 1e-9:
        return np.zeros_like(values)
    return (values - lo) / (hi - lo)


# ---- Shared-road optimization --------------------------------------------
def find_shared_segments(routes, overlap_threshold=0.6):
    """Simple shared-road detector: two routes 'share' a road if the
    Jaccard overlap of their edge sets exceeds the threshold. This is the
    starting point -- a stronger version would work on near-parallel paths
    on the metric graph, not just identical edges, but this is enough to
    demonstrate the concept and report a real shared-road benefit number."""
    shared_pairs = []
    for i, r1 in enumerate(routes):
        edges1 = set(zip(r1[:-1], r1[1:]))
        for j, r2 in enumerate(routes[i + 1:], start=i + 1):
            edges2 = set(zip(r2[:-1], r2[1:]))
            if not edges1 or not edges2:
                continue
            overlap = len(edges1 & edges2) / len(edges1 | edges2)
            if overlap >= overlap_threshold:
                shared_pairs.append((i, j, overlap))
    return shared_pairs


def shared_road_benefit(routes, shared_pairs):
    """Report the length/segment reduction from merging shared routes vs.
    building them independently -- this is the number that goes in your
    shared-road-optimization results table."""
    independent_length = sum(len(r) for r in routes)
    merged_edges = set()
    for r in routes:
        merged_edges.update(zip(r[:-1], r[1:]))
    merged_length = len(merged_edges)
    return dict(
        independent_total_length=independent_length,
        merged_total_length=merged_length,
        length_reduction_pct=100.0 * (1 - merged_length / independent_length) if independent_length else 0.0,
        num_shared_pairs=len(shared_pairs),
    )
