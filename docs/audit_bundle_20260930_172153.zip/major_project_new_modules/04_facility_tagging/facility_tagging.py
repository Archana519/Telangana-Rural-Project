"""
Layer 3 - Facility tagging.

TRACK A (default -- use for every tile): heuristic proxy tagging.
    Without real coordinates (see 03_georeferencing/README), you cannot
    query OpenStreetMap around a tile. Use building geometry as a proxy
    signal instead, and state plainly in the paper that this is a proxy,
    not ground truth -- same honest-limitations style as your mini-project.
    Rationale: in rural LoveDA-style imagery, schools/health centers/
    government buildings tend to be larger, more isolated structures than
    the small, clustered residential buildings around them.

TRACK B (optional, stretch goal): real OSM tagging via the Overpass API,
    only usable for tiles you've manually geolocated
    (03_georeferencing.ManualTileGeoreference).

Both tracks output the same shape: a priority tag per building, so
05_accessibility_priority/ doesn't need to know which track produced it.
"""
import requests

LARGE_BUILDING_PX_AREA = 400   # tune against your dataset's actual building sizes
CLUSTER_RADIUS_PX = 60


def heuristic_priority_tag(building_area_px: float, building_centroid, all_building_centroids):
    """
    Track A. Returns "P1_candidate" (treat as a public-service-like facility)
    or "P2" (treat as residential/other).

    building_area_px: pixel area of this building's connected component
    building_centroid: (x, y) of this building
    all_building_centroids: list of (x, y) for every building in the tile
    """
    cx, cy = building_centroid
    neighbors = [
        (x, y) for (x, y) in all_building_centroids
        if (x, y) != building_centroid
        and (x - cx) ** 2 + (y - cy) ** 2 <= CLUSTER_RADIUS_PX ** 2
    ]
    is_large = building_area_px > LARGE_BUILDING_PX_AREA
    is_isolated_from_cluster = len(neighbors) <= 1
    if is_large and is_isolated_from_cluster:
        return "P1_candidate"
    return "P2"


def tag_all_buildings_heuristic(building_stats):
    """
    building_stats: list of dicts, each with at least {'area': float,
    'centroid': (x, y)} -- exactly what OpenCV's connectedComponentsWithStats
    already gives you in your mini-project's building-detection stage.
    Returns the same list with a 'priority' key added to each dict.
    """
    centroids = [b["centroid"] for b in building_stats]
    for b in building_stats:
        b["priority"] = heuristic_priority_tag(b["area"], b["centroid"], centroids)
    return building_stats


def osm_facility_tags_for_bbox(south: float, west: float, north: float, east: float):
    """
    Track B only. Query the Overpass API for schools/hospitals/government
    buildings inside a real lat/lon bounding box. Only usable for tiles
    you've manually geolocated via 03_georeferencing.ManualTileGeoreference.
    Requires network access and the `requests` package.
    """
    query = f"""
    [out:json][timeout:25];
    (
      node["amenity"~"school|hospital|clinic|townhall|government"]({south},{west},{north},{east});
      way["amenity"~"school|hospital|clinic|townhall|government"]({south},{west},{north},{east});
    );
    out center;
    """
    resp = requests.post(
        "https://overpass-api.de/api/interpreter",
        data={"data": query},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["elements"]


def match_osm_facilities_to_buildings(osm_elements, building_centroids_latlon, buffer_m=20.0):
    """
    Track B. Nearest-neighbor match between OSM facility points and your
    building centroids (already converted to lat/lon via
    ManualTileGeoreference.pixel_to_latlon). Returns a dict:
    {building_index: osm_tag_string_or_None}
    """
    import math

    def haversine_m(lat1, lon1, lat2, lon2):
        R = 6_371_000.0
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dphi = math.radians(lat2 - lat1)
        dlambda = math.radians(lon2 - lon1)
        a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
        return 2 * R * math.asin(math.sqrt(a))

    matches = {}
    for i, (blat, blon) in enumerate(building_centroids_latlon):
        best_tag, best_dist = None, buffer_m
        for el in osm_elements:
            lat = el.get("lat") or el.get("center", {}).get("lat")
            lon = el.get("lon") or el.get("center", {}).get("lon")
            if lat is None or lon is None:
                continue
            d = haversine_m(blat, blon, lat, lon)
            if d < best_dist:
                best_dist = d
                best_tag = el.get("tags", {}).get("amenity")
        matches[i] = best_tag
    return matches
